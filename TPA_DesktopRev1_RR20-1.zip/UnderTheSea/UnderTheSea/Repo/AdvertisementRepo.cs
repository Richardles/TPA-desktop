﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class AdvertisementRepo
    {
        public List<advertisementIdea> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.advertisementIdeas.ToList();
        }

        public void AddAd(advertisementIdea ad)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.advertisementIdeas.Add(ad);
            db.SaveChanges();
        }

        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            advertisementIdea ad = (from adData in db.advertisementIdeas where adData.id == id select adData).FirstOrDefault();
            if (ad == null) return false;
            db.advertisementIdeas.Remove(ad);
            db.SaveChanges();
            return true;
        }

        public advertisementIdea getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            advertisementIdea ad = (from advertisements in db.advertisementIdeas where advertisements.id == id select advertisements).FirstOrDefault();
            return ad;
        }
    }
}
