﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class AdvertisementHandler
    {
        private AdvertisementRepo adRepo;
        private static AdvertisementHandler handler;

        private AdvertisementHandler()
        {
            this.adRepo = new AdvertisementRepo();
        }

        public static AdvertisementHandler GetInstance()
        {
            return (handler == null) ? handler = new AdvertisementHandler() : handler;
        }

        public List<advertisementIdea> GetAll()
        {
            return adRepo.GetAll();
        }

        public bool InsertAd(int id, string idea, string status, string purchase, string fund)
        {
            advertisementIdea ad = AdvertisementFactory.CreateAd(id, idea, status, purchase, fund);
            adRepo.AddAd(ad);
            return true;
        }
        public bool InsertAd(int id, string idea, string status)
        {
            advertisementIdea ad = AdvertisementFactory.CreateAd(id, idea, status);
            adRepo.AddAd(ad);
            return true;
        }

        public bool Update(int id, string approval)
        {
            advertisementIdea temp = adRepo.getOne(id);
            adRepo.Remove(id);
            advertisementIdea ad = AdvertisementFactory.CreateAd(temp.id, temp.idea, temp.status, temp.Purchase_Request, temp.Fund_Request, approval);
            adRepo.AddAd(ad);
            return true;
        }

        public bool Remove(int id)
        {
            advertisementIdea temp = adRepo.getOne(id);
            adRepo.Remove(id);
            advertisementIdea ad = AdvertisementFactory.CreateAd(temp.id, temp.idea, "Removed", temp.Purchase_Request, temp.Fund_Request, temp.Request_Status);
            adRepo.AddAd(ad);
            return true;
        }

        public bool RequestPurchase(int id, string req)
        {
            advertisementIdea temp = adRepo.getOne(id);
            adRepo.Remove(id);
            advertisementIdea ad = AdvertisementFactory.CreateAd(temp.id, temp.idea, temp.status, req, temp.Fund_Request, "Waiting For Approval");
            adRepo.AddAd(ad);
            return true;
        }

        public bool RequestFund(int id, string req)
        {
            advertisementIdea temp = adRepo.getOne(id);
            adRepo.Remove(id);
            advertisementIdea ad = AdvertisementFactory.CreateAd(temp.id, temp.idea, temp.status, temp.Purchase_Request, req, "Waiting For Approval");
            adRepo.AddAd(ad);
            return true;
        }

        public bool Delete(int id)
        {
            return adRepo.Remove(id);
        }

        public advertisementIdea GetOne(int id)
        {
            return adRepo.getOne(id);
        }
    }
}
