﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for PurchasingUI.xaml
    /// </summary>
    public partial class PurchasingUI : Window
    {
        public PurchasingUI()
        {
            InitializeComponent();
            hidePurchaseForm();
            viewPurchase();
        }

        private void viewPurchase()
        {
            var pur = PurchaseRequestHandler.GetInstance().GetAll();
            purchase_table.ItemsSource = pur;
        }

        private void fund_form_Click(object sender, RoutedEventArgs e)
        {
            FundRequestForm f = new FundRequestForm("Purchasing");
            f.Show();
            this.Close();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void purchase_Click(object sender, RoutedEventArgs e)
        {
            purchase_table.Visibility = Visibility.Hidden;
            showPurchaseForm();
        }

        private void showPurchaseForm()
        {
            detailLbl.Visibility = Visibility.Visible;
            detailField.Visibility = Visibility.Visible;
            priceLbl.Visibility = Visibility.Visible;
            priceField.Visibility = Visibility.Visible;
            submitBtn.Visibility = Visibility.Visible;
        }

        private void hidePurchaseForm()
        {
            detailLbl.Visibility = Visibility.Hidden;
            detailField.Visibility = Visibility.Hidden;
            priceLbl.Visibility = Visibility.Hidden;
            priceField.Visibility = Visibility.Hidden;
            submitBtn.Visibility = Visibility.Hidden;
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            var detail = detailField.Text;
            var price = priceField.Text;
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            purchaseDetail p = CreatePurchase(detail, price);
            db.purchaseDetails.Add(p);
            db.SaveChanges();
            detailField.Text = "";
            priceField.Text = "";
            MessageBox.Show("Success!");
        }

        public static purchaseDetail CreatePurchase(string detail, string price)
        {
            purchaseDetail p = new purchaseDetail();
            p.purchase_detail = detail;
            p.total_price = price;
            return p;
        }

        private void showReq_Click(object sender, RoutedEventArgs e)
        {
            hidePurchaseForm();
            purchase_table.Visibility = Visibility.Visible;
        }
    }
}
