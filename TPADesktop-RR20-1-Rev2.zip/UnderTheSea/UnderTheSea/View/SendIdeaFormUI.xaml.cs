﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for SendIdeaFormUI.xaml
    /// </summary>
    public partial class SendIdeaFormUI : Window
    {
        public SendIdeaFormUI()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            RideandAttractionCreativeDepartment r = new RideandAttractionCreativeDepartment();
            r.Show();
            this.Close();
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            int id = 0;
            var name = nameField.Text;
            var type = typeField.Text;
            var detail = detailField.Text;
            idea idea = new idea();
            idea i;
            do
            {
                id++;
                i = (from ideas in db.ideas where ideas.id == id select ideas).FirstOrDefault();
            } while (i != null);
            idea.id = id;
            idea.idea_name = name;
            idea.type = type;
            idea.detail = detail;
            idea.status = "Waiting for approval";
            db.ideas.Add(idea);
            db.SaveChanges();
        }
    }
}
