﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ResignForm.xaml
    /// </summary>
    public partial class ResignForm : Window
    {
        string pos;
        public ResignForm(string pos)
        {
            this.pos = pos;
            InitializeComponent();
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            var name = name_field.Text;
            var pos = pos_field.Text;
            var desc = desc_field.Text;
            resignReq req;
            do
            {
                id++;
                req = ResignReqHandler.GetInstance().getOne(id);
            } while (req != null);
            ResignReqHandler.GetInstance().InsertReq(id.ToString(), name, pos, desc, "Waiting for approval");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            checkPos(pos);
        }

        public void checkPos(string pos)
        {
            if (pos.Equals("Sales and Marketing"))
            {
                SalesAndMarketingUI sm = new SalesAndMarketingUI();
                sm.Show();
                this.Close();
            }
            else if (pos.Equals("Accounting and Finance"))
            {
                AccountingAndFinanceUI ac = new AccountingAndFinanceUI();
                ac.Show();
                this.Close();
            }
            else if (pos.Equals("Ride and Attraction Creative"))
            {
                RideandAttractionCreativeDepartment c = new RideandAttractionCreativeDepartment();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("Construction"))
            {
                ConstructionUI c = new ConstructionUI();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("HRD"))
            {
                HRDUI h = new HRDUI();
                h.Show();
                this.Close();
            }
            else if (pos.Equals("Manager"))
            {
                Manager m = new Manager();
                m.Show();
                this.Close();
            }
        }
    }
}
