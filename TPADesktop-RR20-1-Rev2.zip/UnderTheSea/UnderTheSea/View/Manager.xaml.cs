﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for Manager.xaml
    /// </summary>
    public partial class Manager : Window
    {
        string currTable;
        int id;
        public Manager()
        {
            InitializeComponent();
            ViewEmp();
            ViewResignReq();
        }

        private void ViewEmp()
        {
            var emps = EmployeeHandler.GetInstance().GetAll();
            emp_table.ItemsSource = emps;
            currTable = "emp";
        }

        private void ViewResignReq()
        {
            var reqs = ResignReqHandler.GetInstance().GetAll();
            emp_table.ItemsSource = reqs;
            currTable = "resignReq";
        }

        private void ViewIdea()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            var ideas = db.ideas.ToList();
            emp_table.ItemsSource = ideas;
            currTable = "ideaReq";
        }

        private void resign_Click(object sender, RoutedEventArgs e)
        {
            ViewResignReq();
        }

        private void emp_Click(object sender, RoutedEventArgs e)
        {
            ViewEmp();
        }

        private void reject_resignReq_Click(object sender, RoutedEventArgs e)
        {
            if (currTable.Equals("resignReq"))
            {
                ResignReqHandler.GetInstance().Update(id, "Rejected");
                ViewResignReq();
            }
            else if (currTable.Equals("ideaReq"))
            {
                UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
                idea temp = (from ideas in db.ideas where ideas.id == id select ideas).FirstOrDefault();
                idea del = (from ideas in db.ideas where ideas.id == id select ideas).FirstOrDefault();
                db.ideas.Remove(del);
                db.SaveChanges();
                updateIdea(temp, "Rejected");
                ViewIdea();
            }
        }

        private void approve_resignReq_Click(object sender, RoutedEventArgs e)
        {
            if (currTable.Equals("resignReq"))
            {
                ResignReqHandler.GetInstance().Update(id, "Approved");
                ViewResignReq();
            }
            else if (currTable.Equals("ideaReq"))
            {
                UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
                idea temp = (from ideas in db.ideas where ideas.id == id select ideas).FirstOrDefault();
                idea del = (from ideas in db.ideas where ideas.id == id select ideas).FirstOrDefault();
                db.ideas.Remove(del);
                db.SaveChanges();
                updateIdea(temp, "Approved");
                ViewIdea();
            }
        }

        private void updateIdea(idea id, string status)
        {
            idea i = new idea();
            i.id = id.id;
            i.idea_name = id.idea_name;
            i.type = id.type;
            i.detail = id.detail;
            i.status = status;
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.ideas.Add(i);
            db.SaveChanges();
        }

        private void idea_Click(object sender, RoutedEventArgs e)
        {
            ViewIdea();
        }

        private void emp_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            if (currTable.Equals("resignReq"))
            {
                var req = (resignReq)a.SelectedItem;
                if (req != null)
                {
                    id = req.id;
                }
            }else if (currTable.Equals("ideaReq"))
            {
                var i = (idea)a.SelectedItem;
                if (i != null)
                {
                    id = i.id;
                }
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
