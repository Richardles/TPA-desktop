﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for FrontOfficeUI.xaml
    /// </summary>
    public partial class FrontOfficeUI : Window
    {
        int number;
        public FrontOfficeUI()
        {
            InitializeComponent();
            viewRoom();
        }

        private void viewRoom()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            var rooms = db.rooms.ToList();
            room_table.ItemsSource = rooms;
        }

        private void reserve_Click(object sender, RoutedEventArgs e)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            room temp = getOne(number);
            room del = (from rooms in db.rooms where rooms.room_number == number select rooms).FirstOrDefault();
            if (temp == null)
            {
                MessageBox.Show("Room not exists");
            }
            db.rooms.Remove(del);
            db.SaveChanges();
            AddRoom(temp, "Reserved");
            viewRoom();
        }
        public room getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            room room = (from rooms in db.rooms where rooms.room_number == id select rooms).FirstOrDefault();
            return room;
        }

        public void AddRoom(room room, string status)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();

            room r = new room();
            r.room_number = room.room_number;
            r.type = room.type;
            r.status = status;
            db.rooms.Add(r);
            db.SaveChanges();
        }

        private void occupied()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            room temp = getOne(number);
            room del = (from rooms in db.rooms where rooms.room_number == number select rooms).FirstOrDefault();
            if (temp == null)
            {
                MessageBox.Show("Room not exists");
            }
            db.rooms.Remove(del);
            db.SaveChanges();
            AddRoom(temp, "Occupied");
            viewRoom();
        }

        private void room_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var room = (room)a.SelectedItem;
            if (room != null)
            {
                number = room.room_number;
                roomLbl.Content = number.ToString();
            }
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            cancelReservation();
        }

        private void cancelReservation()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            room temp = getOne(number);
            room del = (from rooms in db.rooms where rooms.room_number == number select rooms).FirstOrDefault();
            if (temp == null)
            {
                MessageBox.Show("Room not exists");
            }
            db.rooms.Remove(del);
            db.SaveChanges();
            AddRoom(temp, "available");
            viewRoom();
        }

        private void check_in_Click(object sender, RoutedEventArgs e)
        {
            string time = DateTime.Now.TimeOfDay.ToString();
            string hour = time.Substring(0, 2);
            if (!hour.Equals("10"))
            {
                MessageBox.Show("Check In Time is 10 a.m ");
            }
            else
            {
                var id = idField.Text;
                visitor v = VisitorHandler.GetInstance().GetOne(int.Parse(id));
                if (v == null)
                {
                    RegisterVisitorUI r = new RegisterVisitorUI();
                    r.Show();
                    this.Close();
                }
                occupied();
                MessageBox.Show("Success!");
            }
        }

        private void check_out_Click(object sender, RoutedEventArgs e)
        {
            string time = DateTime.Now.TimeOfDay.ToString();
            string hour = time.Substring(0, 2);
            if (!hour.Equals("08"))
            {
                MessageBox.Show("Check Out Time is 8 a.m");
            }
            else
            {
                cancelReservation();
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
