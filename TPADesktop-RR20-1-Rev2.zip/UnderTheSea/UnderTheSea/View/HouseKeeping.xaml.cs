﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for HouseKeeping.xaml
    /// </summary>
    public partial class HouseKeeping : Window
    {
        public HouseKeeping()
        {
            InitializeComponent();
            hideSetNoteForm();
            viewRoom();
        }

        private void viewRoom()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            var rooms = db.rooms.ToList();
            room_table.ItemsSource = rooms;
        }

        private void view_room_Click(object sender, RoutedEventArgs e)
        {
            hideSetNoteForm();
            room_table.Visibility = Visibility.Visible;
        }

        private void note_Click(object sender, RoutedEventArgs e)
        {
            room_table.Visibility = Visibility.Hidden;
            showSetNoteForm();
        }

        private void showSetNoteForm()
        {
            numberLbl.Visibility = Visibility.Visible;
            numberField.Visibility = Visibility.Visible;
            noteLbl.Visibility = Visibility.Visible;
            noteField.Visibility = Visibility.Visible;
            submitBtn.Visibility = Visibility.Visible;
        }

        private void hideSetNoteForm()
        {
            numberLbl.Visibility = Visibility.Hidden;
            numberField.Visibility = Visibility.Hidden;
            noteLbl.Visibility = Visibility.Hidden;
            noteField.Visibility = Visibility.Hidden;
            submitBtn.Visibility = Visibility.Hidden;
        }

        private void submitBtn_Click(object sender, RoutedEventArgs e)
        {
            var num = numberField.Text;
            var note = noteField.Text;
            roomNote rn = new roomNote();
            rn.room_number = int.Parse(num);
            rn.note = note;
            rn.date = DateTime.Now.ToString();
            insertNote(rn);
            numberField.Text = "";
            noteField.Text = "";
            MessageBox.Show("Success!");
        }

        private void insertNote(roomNote rn)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.roomNotes.Add(rn);
            db.SaveChanges();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
