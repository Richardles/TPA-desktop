﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for HRDUI.xaml
    /// </summary>
    public partial class HRDUI : Window
    {
        public HRDUI()
        {
            InitializeComponent();
            ViewEmp();
        }
        private void ViewEmp()
        {
            var emps = EmployeeHandler.GetInstance().GetAll();
            emp_table.ItemsSource = emps;
        }

        private void emp_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var emp = (employee)a.SelectedItem;
            if (emp != null)
            {
                id_field.Text = emp.id.ToString();
                name_field.Text = emp.name;
                password_field.Text = emp.password;
                salary_field.Text = emp.salary;
                position_field.Text = emp.position;
                status_field.Text = emp.status;
                bank_acc_field.Text = emp.bank_account;
                wp_field.Text = emp.work_performance;
            }
        }

        private void insert_Click(object sender, RoutedEventArgs e)
        {
            var id = id_field.Text;
            var name = name_field.Text;
            var pass = password_field.Text;
            var salary = salary_field.Text;
            var position = position_field.Text;
            var status = status_field.Text;
            var bankAcc = bank_acc_field.Text;
            var wp = wp_field.Text;
            EmployeeHandler.GetInstance().InsertEmp(id, pass, name, salary, position, status, bankAcc, wp);
            ViewEmp();
            Refresh();
        }

        private void Refresh()
        {
            id_field.Text = "";
            name_field.Text = "";
            password_field.Text = "";
            salary_field.Text = "";
            position_field.Text = "";
            status_field.Text = "";
            bank_acc_field.Text = "";
            wp_field.Text = "";
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();   
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            var id = id_field.Text;
            var name = name_field.Text;
            var pass = password_field.Text;
            var salary = salary_field.Text;
            var position = position_field.Text;
            var status = status_field.Text;
            var bankAcc = bank_acc_field.Text;
            var wp = wp_field.Text;
            EmployeeHandler.GetInstance().Update(id, pass, name, salary, position, status, bankAcc, wp);
            ViewEmp();
        }

        private void fire_Click(object sender, RoutedEventArgs e)
        {
            var id = id_field.Text;
            EmployeeHandler.GetInstance().Fire(id);
            ViewEmp();
        }

        private void resign_Click(object sender, RoutedEventArgs e)
        {
            ResignForm r = new ResignForm("HRD");
            r.Show();
            this.Close();
        }
    }
}
