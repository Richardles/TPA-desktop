﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for RegisterVisitorUI.xaml
    /// </summary>
    public partial class RegisterVisitorUI : Window
    {
        public RegisterVisitorUI()
        {
            InitializeComponent();
        }

        private void submitBtn_Click(object sender, RoutedEventArgs e)
        {
            var name = nameField.Text;
            var payType = payField.Text;
            var bankAcc = bankField.Text;
            VisitorHandler.GetInstance().InsertVisitor(name, payType, bankAcc);
            nameField.Text = "";
            payField.Text = "";
            bankField.Text = "";
            MessageBox.Show("Success!");
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            FrontOfficeUI f = new FrontOfficeUI();
            f.Show();
            this.Close();
        }
    }
}
