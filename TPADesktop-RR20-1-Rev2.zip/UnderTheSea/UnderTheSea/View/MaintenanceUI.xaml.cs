﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for MaintenanceUI.xaml
    /// </summary>
    public partial class MaintenanceUI : Window
    {
        int id;
        string chosen;
        public MaintenanceUI()
        {
            InitializeComponent();
            viewRide();
            viewAttr();
            hideRideAttrForm();
            hideAddNoteForm();
            viewSchedule();
        }

        private void viewSchedule()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            var sc = db.maintenanceSchedules.ToList();
            schedule_table.ItemsSource = sc;
        }

        private void viewRide()
        {
            var rides = RideHandler.GetInstance().GetAll();
            ride_table.ItemsSource = rides;
        }

        private void viewAttr()
        {
            var attr = AttractionHandler.GetInstance().GetAll();
            attr_table.ItemsSource = attr;
        }

        private void schedule_Click(object sender, RoutedEventArgs e)
        {
            hideRideAttrForm();
            hideAddNoteForm();
            schedule_table.Visibility = Visibility.Visible;
        }

        private void ride_attr_Click(object sender, RoutedEventArgs e)
        {
            schedule_table.Visibility = Visibility.Hidden;
            hideAddNoteForm();
            showRideAttrForm();
        }

        private void showRideAttrForm()
        {
            rideLbl.Visibility = Visibility.Visible;
            attrLbl.Visibility = Visibility.Visible;
            ride_table.Visibility = Visibility.Visible;
            attr_table.Visibility = Visibility.Visible;
            statusLbl.Visibility = Visibility.Visible;
            statusField.Visibility = Visibility.Visible;
            updateStatusBtn.Visibility = Visibility.Visible;
        }

        private void hideRideAttrForm()
        {
            rideLbl.Visibility = Visibility.Hidden;
            attrLbl.Visibility = Visibility.Hidden;
            ride_table.Visibility = Visibility.Hidden;
            attr_table.Visibility = Visibility.Hidden;
            statusLbl.Visibility = Visibility.Hidden;
            statusField.Visibility = Visibility.Hidden;
            updateStatusBtn.Visibility = Visibility.Hidden;
        }
        private void showAddNoteForm()
        {
            rideAttrLbl.Visibility = Visibility.Visible;
            rideAttrNameField.Visibility = Visibility.Visible;
            noteLbl.Visibility = Visibility.Visible;
            noteField.Visibility = Visibility.Visible;
            submitBtn.Visibility = Visibility.Visible;
        }
        private void hideAddNoteForm()
        {
            rideAttrLbl.Visibility = Visibility.Hidden;
            rideAttrNameField.Visibility = Visibility.Hidden;
            noteLbl.Visibility = Visibility.Hidden;
            noteField.Visibility = Visibility.Hidden;
            submitBtn.Visibility = Visibility.Hidden;
        }

        private void add_note_Click(object sender, RoutedEventArgs e)
        {
            schedule_table.Visibility = Visibility.Hidden;
            hideRideAttrForm();
            showAddNoteForm();
        }

        private void ride_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var ride = (ride)a.SelectedItem;
            if (ride != null)
            {
                id = ride.rideId;
                chosen = "Ride";
                statusLbl.Content = ride.name;
                statusField.Text = "";
                statusField.Text = ride.status;
            }
        }

        private void attr_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var attr = (attraction)a.SelectedItem;
            if (attr != null)
            {
                id = attr.attractionId;
                chosen = "Attr";
                statusLbl.Content = attr.name;
                statusField.Text = "";
                statusField.Text = attr.status;
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void updateStatusBtn_Click(object sender, RoutedEventArgs e)
        {
            var status = statusField.Text;
            if (chosen.Equals("Ride"))
            {
                RideHandler.GetInstance().Update(id.ToString(), status);
            }else if (chosen.Equals("Attr"))
            {
                AttractionHandler.GetInstance().Update(id.ToString(), status);
            }
            viewRide();
            viewAttr();
        }

        private void submitBtn_Click(object sender, RoutedEventArgs e)
        {
            var name = rideAttrNameField.Text;
            var note = noteField.Text;
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            maintenanceNote n = new maintenanceNote();
            n.ride_or_attraction_name = name;
            n.notes = note;
            n.date = DateTime.Now.ToString();
            db.maintenanceNotes.Add(n);
            db.SaveChanges();
            rideAttrNameField.Text = "";
            noteField.Text = "";
            MessageBox.Show("Submit Success");
        }
    }
}
