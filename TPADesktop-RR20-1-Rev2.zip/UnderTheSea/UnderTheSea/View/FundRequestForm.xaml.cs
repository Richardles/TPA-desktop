﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for FundRequestForm.xaml
    /// </summary>
    public partial class FundRequestForm : Window
    {
        string dept;
        public FundRequestForm(string dept)
        {
            this.dept = dept;
            InitializeComponent();
            deptField.Text = dept;
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            var req = reqField.Text;
            fundRequest fund;
            do
            {
                id++;
                fund = FundRequestsHandler.GetInstance().getOne(id);
            } while (fund != null);
            FundRequestsHandler.GetInstance().InsertReq(id.ToString(), dept, req, "Waiting for approval");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            checkPos(dept);
        }

        public void checkPos(string pos)
        {
            if (pos.Equals("Sales and Marketing"))
            {
                SalesAndMarketingUI sm = new SalesAndMarketingUI();
                sm.Show();
                this.Close();
            }
            else if (pos.Equals("Accounting and Finance"))
            {
                AccountingAndFinanceUI ac = new AccountingAndFinanceUI();
                ac.Show();
                this.Close();
            }
            else if (pos.Equals("Ride and Attraction Creative"))
            {
                RideandAttractionCreativeDepartment c = new RideandAttractionCreativeDepartment();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("Construction"))
            {
                ConstructionUI c = new ConstructionUI();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("HRD"))
            {
                HRDUI h = new HRDUI();
                h.Show();
                this.Close();
            }
            else if (pos.Equals("Manager"))
            {
                Manager m = new Manager();
                m.Show();
                this.Close();
            }
            else if (pos.Equals("Purchasing"))
            {
                PurchasingUI m = new PurchasingUI();
                m.Show();
                this.Close();
            }
        }
    }
}
