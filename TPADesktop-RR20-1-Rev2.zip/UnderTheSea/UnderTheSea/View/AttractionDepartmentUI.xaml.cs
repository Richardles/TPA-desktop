﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AttractionDepartmentUI.xaml
    /// </summary>
    public partial class AttractionDepartmentUI : Window
    {
        int price = 500000;
        int chosenAttrRide;
        string chosenPlace;
        attraction attr;
        ride ride;
        public AttractionDepartmentUI()
        {
            InitializeComponent();
            hideSetGuardForm();
            hideValidateForm();
            ViewRide();
            ViewAttraction();
            ViewEmp();
        }
        private void ViewRide()
        {
            var rides = RideHandler.GetInstance().GetAll();
            ride_table.ItemsSource = rides;
        }

        private void ViewAttraction()
        {
            var attractions = AttractionHandler.GetInstance().GetAll();
            attraction_table.ItemsSource = attractions;
        }

        private void ViewEmp()
        {
            var emps = EmployeeHandler.GetInstance().GetAll();
            emp_table.ItemsSource = emps;
        }

        private void sell_Click(object sender, RoutedEventArgs e)
        {
            int qty = int.Parse(qty_field.Text);
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            for (int i = 0; i < qty; i++)
            {
                ticket ticket = new ticket();
                ticket.price = price.ToString();
                ticket.expire_time = DateTime.Now.ToString();
                db.tickets.Add(ticket);
                db.SaveChanges();
            }
            ticketTransaction tr = new ticketTransaction();
            tr.ticket_quantity = qty;
            tr.date = DateTime.Now.ToString();
            db.ticketTransactions.Add(tr);
            db.SaveChanges();
        }

        private void view_sell_form_Click(object sender, RoutedEventArgs e)
        {
            hideSetGuardForm();
            hideValidateForm();
            showSellForm();
        }

        private void hideSellForm()
        {
            qtyLbl.Visibility = Visibility.Hidden;
            qty_field.Visibility = Visibility.Hidden;
            totalLbl.Visibility = Visibility.Hidden;
            totalPriceLbl.Visibility = Visibility.Hidden;
            printBtn.Visibility = Visibility.Hidden;
        }

        private void showSellForm()
        {
            qtyLbl.Visibility = Visibility.Visible;
            qty_field.Visibility = Visibility.Visible;
            totalLbl.Visibility = Visibility.Visible;
            totalPriceLbl.Visibility = Visibility.Visible;
            printBtn.Visibility = Visibility.Visible;
        }

        private void set_guard_Click(object sender, RoutedEventArgs e)
        {
            hideSellForm();
            hideValidateForm();
            showSetGuardForm();
        }

        private void showSetGuardForm()
        {
            ride_table.Visibility = Visibility.Visible;
            attraction_table.Visibility = Visibility.Visible;
            emp_table.Visibility = Visibility.Visible;
            set_guard_Btn.Visibility = Visibility.Visible;
            ride_attr_field.Visibility = Visibility.Visible;
            chosen_emp_field.Visibility = Visibility.Visible;
        }

        private void hideSetGuardForm()
        {
            ride_table.Visibility = Visibility.Hidden;
            attraction_table.Visibility = Visibility.Hidden;
            emp_table.Visibility = Visibility.Hidden;
            set_guard_Btn.Visibility = Visibility.Hidden;
            ride_attr_field.Visibility = Visibility.Hidden;
            chosen_emp_field.Visibility = Visibility.Hidden;
        }

        private void ride_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            ride = (ride)a.SelectedItem;
            if (ride != null)
            {
                chosenPlace = "Ride";
                chosenAttrRide = ride.rideId;
                ride_attr_field.Text = ride.name;
            }
        }

        private void attraction_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            attr = (attraction)a.SelectedItem;
            if (attr != null)
            {
                chosenPlace = "Attr";
                chosenAttrRide = attr.attractionId;
                ride_attr_field.Text = attr.name;
            }
        }

        private void emp_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var emp = (employee)a.SelectedItem;
            if (emp != null)
            {
                chosen_emp_field.Text = emp.name;
            }
        }

        private void set_guard_Btn_Click(object sender, RoutedEventArgs e)
        {
            employee emp = EmployeeHandler.GetInstance().getOne(chosen_emp_field.Text);

            if (emp.position != "Guards")
            {
                MessageBox.Show("Employee position not valid");
            }
            else
            {
                if (chosenPlace.Equals("Ride"))
                {
                    string guards = emp.name;
                    string status = "Guarding " + ride.name;
                    RideHandler.GetInstance().Update(ride.rideId, guards);
                    EmployeeHandler.GetInstance().Update(emp.id, status);
                }else if (chosenPlace.Equals("Attr"))
                {
                    string guards = emp.name;
                    string status = "Guarding " + attr.name;
                    AttractionHandler.GetInstance().Update(attr.attractionId, guards);
                    EmployeeHandler.GetInstance().Update(emp.id, status);
                }
            }
            ViewAttraction();
            ViewRide();
            ViewEmp();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void validate_Click(object sender, RoutedEventArgs e)
        {
            hideSellForm();
            hideSetGuardForm();
            showValidateForm();
        }

        private void validateBtn_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(ticketIdField.Text);
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            ticket ticket = (from tickets in db.tickets where tickets.id == id select tickets).FirstOrDefault();
            if (ticket == null)
            {
                MessageBox.Show("Invalid ticket id");
            }
            else
            {
                string dateNow = DateTime.Now.ToString();
                string date = dateNow.Substring(0, 1);
                string ticketDate = ticket.expire_time.Substring(0, 1);
                if (date.Equals(ticketDate))
                {
                    MessageBox.Show("Ticket is valid until "+ ticket.expire_time.Substring(0, ticket.expire_time.IndexOf(" ")) +", welcome!");
                }
                else
                {
                    MessageBox.Show("Ticket is expired!\nExpired time : " + ticket.expire_time.Substring(0, ticket.expire_time.IndexOf(" ")));
                }
            }
        }

        private void showValidateForm()
        {
            ticketIdLbl.Visibility = Visibility.Visible;
            ticketIdField.Visibility = Visibility.Visible;
            validateBtn.Visibility = Visibility.Visible;
        }

        private void hideValidateForm()
        {
            ticketIdLbl.Visibility = Visibility.Hidden;
            ticketIdField.Visibility = Visibility.Hidden;
            validateBtn.Visibility = Visibility.Hidden;
        }
    }
}
