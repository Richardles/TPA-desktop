﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for ConstructionUI.xaml
    /// </summary>
    public partial class ConstructionUI : Window
    {
        int id;
        public ConstructionUI()
        {
            InitializeComponent();
            ViewRide();
        }
        private void ViewRide()
        {
            var rides = RideHandler.GetInstance().GetAll();
            ride_table.ItemsSource = rides;
        }

        private void remove_Click(object sender, RoutedEventArgs e)
        {
            RideHandler.GetInstance().Remove(id);
            ViewRide();
            status_field.Text = "";
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            var status = status_field.Text;
            RideHandler.GetInstance().Update(id.ToString(), status);
            ViewRide();
            status_field.Text = "";
        }

        private void ride_table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var ride = (ride)a.SelectedItem;
            if (ride != null)
            {
                id = ride.rideId;
                name_lbl.Content = ride.name;
                status_field.Text = ride.status;
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void purchase_Click(object sender, RoutedEventArgs e)
        {
            PurchaseRequestForm f = new PurchaseRequestForm("Construction");
            f.Show();
            this.Close();
        }

        private void fund_Click(object sender, RoutedEventArgs e)
        {
            FundRequestForm f = new FundRequestForm("Construction");
            f.Show();
            this.Close();
        }
    }
}
