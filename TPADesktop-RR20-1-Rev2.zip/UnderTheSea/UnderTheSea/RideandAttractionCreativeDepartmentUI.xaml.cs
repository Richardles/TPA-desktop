﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;
using UnderTheSea.View;

namespace UnderTheSea
{
    /// <summary>
    /// Interaction logic for RideandAttractionCreativeDepartment.xaml
    /// </summary>
    public partial class RideandAttractionCreativeDepartment : Window
    {
        int id;
        public RideandAttractionCreativeDepartment()
        {
            InitializeComponent();
            ViewRide();
            ViewAttraction();
        }

        private void ViewRide()
        {
            var rides = RideHandler.GetInstance().GetAll();
            if (rides != null)
            {
                rideTable.ItemsSource = rides;
            }
        }

        private void ViewAttraction()
        {
            var attractions = AttractionHandler.GetInstance().GetAll();
            attractionTable.ItemsSource = attractions;
        }

        private void Add_ride_Click(object sender, RoutedEventArgs e)
        {
            var id = rideIdField.Text;
            var name = rideNameField.Text;
            var description = rideDescField.Text;
            var status = rideStatsField.Text;
            string guards = "None";
            RideHandler.GetInstance().InsertRide(id, name, description, status, guards);
            ViewRide();
        }

        private void Remove_ride_Click(object sender, RoutedEventArgs e)
        {
            RideHandler.GetInstance().Remove(id);
            ViewRide();
        }

        private void rideTable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var ride = (ride)a.SelectedItem;
            if (ride != null)
            {
                id = ride.rideId;
                rideIdField.Text = ride.rideId.ToString();
                rideNameField.Text = ride.name;
                rideDescField.Text = ride.description;
                rideStatsField.Text = ride.status;
            }
        }

        private void Update_ride_Click(object sender, RoutedEventArgs e)
        {
            var id = rideIdField.Text;
            var name = rideNameField.Text;
            var description = rideDescField.Text;
            var status = rideStatsField.Text;
            RideHandler.GetInstance().Update(id, name, description, status);
            ViewRide();
        }

        private void Add_attr_Click(object sender, RoutedEventArgs e)
        {
            var id = attrIdField.Text;
            var name = attrNameField.Text;
            var description = attrDescField.Text;
            var status = attrStatsField.Text;
            string guards = "None";
            AttractionHandler.GetInstance().InsertAttr(id, name, description, status, guards);
            ViewAttraction();
        }

        private void Remove_attr_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(attrIdField.Text);
            AttractionHandler.GetInstance().Remove(id);
            ViewAttraction();
        }

        private void Update_attr_Click(object sender, RoutedEventArgs e)
        {
            var id = attrIdField.Text;
            var name = attrNameField.Text;
            var description = attrDescField.Text;
            var status = attrStatsField.Text;
            AttractionHandler.GetInstance().Update(id, name, description, status);
            ViewAttraction();
        }

        private void attractionTable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var attr = (attraction)a.SelectedItem;
            if (attr != null)
            {
                attrIdField.Text = attr.attractionId.ToString();
                attrNameField.Text = attr.name;
                attrDescField.Text = attr.description;
                attrStatsField.Text = attr.status;
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void idea_Click(object sender, RoutedEventArgs e)
        {
            SendIdeaFormUI s = new SendIdeaFormUI();
            s.Show();
            this.Close();
        }

        private void purchase_Click(object sender, RoutedEventArgs e)
        {
            PurchaseRequestForm f = new PurchaseRequestForm("Ride and Attraction Creative");
            f.Show();
            this.Close();
        }

        private void fund_req_Click(object sender, RoutedEventArgs e)
        {
            FundRequestForm f = new FundRequestForm("Ride and Attraction Creative");
            f.Show();
            this.Close();
        }
    }
}
