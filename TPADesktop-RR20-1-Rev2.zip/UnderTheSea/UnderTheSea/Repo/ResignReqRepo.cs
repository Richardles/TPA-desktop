﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class ResignReqRepo
    {
        public List<resignReq> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.resignReqs.ToList();
        }

        public void AddReq(resignReq req)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.resignReqs.Add(req);
            db.SaveChanges();
        }

        public resignReq getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            resignReq req = (from reqs in db.resignReqs where reqs.id == id select reqs).FirstOrDefault();
            return req;
        }

        public void Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            resignReq req = (from reqs in db.resignReqs where reqs.id == id select reqs).FirstOrDefault();
            db.resignReqs.Remove(req);
            db.SaveChanges();
        }
    }
}
