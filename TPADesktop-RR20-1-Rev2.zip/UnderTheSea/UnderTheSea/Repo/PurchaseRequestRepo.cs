﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class PurchaseRequestRepo
    {
        public List<purchase> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.purchases.ToList();
        }

        public void AddReq(purchase pur)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.purchases.Add(pur);
            db.SaveChanges();
        }
        public purchase getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            purchase pur = (from purs in db.purchases where purs.id == id select purs).FirstOrDefault();
            return pur;
        }
        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            purchase pur = (from purs in db.purchases where purs.id == id select purs).FirstOrDefault();
            if (pur == null) return false;
            db.purchases.Remove(pur);
            db.SaveChanges();
            return true;
        }
    }
}
