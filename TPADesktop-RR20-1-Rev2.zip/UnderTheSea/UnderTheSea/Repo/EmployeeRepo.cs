﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class EmployeeRepo
    {
        public List<employee> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.employees.ToList();
        }

        public void AddEmp(employee emp)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.employees.Add(emp);
            db.SaveChanges();
        }

        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            employee emp = (from emps in db.employees where emps.id == id select emps).FirstOrDefault();
            if (emp == null) return false;
            db.employees.Remove(emp);
            db.SaveChanges();
            return true;
        }

        public employee getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            employee emp = (from emps in db.employees where emps.id == id select emps).FirstOrDefault();
            return emp;
        }

        public employee getOne(string username)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            employee emp = (from emps in db.employees where emps.name == username select emps).FirstOrDefault();
            return emp;
        }
    }
}
