﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class FundRequestsRepo
    {
        public List<fundRequest> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.fundRequests.ToList();
        }

        public void AddReq(fundRequest fund)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.fundRequests.Add(fund);
            db.SaveChanges();
        }
        public fundRequest getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            fundRequest fund = (from funds in db.fundRequests where funds.id == id select funds).FirstOrDefault();
            return fund;
        }
        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            fundRequest fund = (from funds in db.fundRequests where funds.id == id select funds).FirstOrDefault();
            if (fund == null) return false;
            db.fundRequests.Remove(fund);
            db.SaveChanges();
            return true;
        }
    }
}
