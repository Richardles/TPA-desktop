﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class AttractionRepo
    {
        public List<attraction> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.attractions.ToList();
        }

        public void AddAttr(attraction attr)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.attractions.Add(attr);
            db.SaveChanges();
        }

        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            attraction attr = (from attrs in db.attractions where attrs.attractionId == id select attrs).FirstOrDefault();
            if (attr == null) return false;
            db.attractions.Remove(attr);
            db.SaveChanges();
            return true;
        }

        public attraction getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            attraction attr = (from attrs in db.attractions where attrs.attractionId == id select attrs).FirstOrDefault();
            return attr;
        }
    }
}
