﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class VisitorRepo
    {
        public void AddVisitor(visitor visitor)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.visitors.Add(visitor);
            db.SaveChanges();
        }

        public visitor getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            visitor visitor = (from visitors in db.visitors where visitors.id == id select visitors).FirstOrDefault();
            return visitor;
        }
    }
}
