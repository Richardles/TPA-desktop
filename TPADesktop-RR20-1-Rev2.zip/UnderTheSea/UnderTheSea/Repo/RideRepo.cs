﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using UnderTheSea.Model;

namespace UnderTheSea.Repo
{
    class RideRepo
    {
        public List<ride> GetAll()
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            return db.rides.ToList();
        }

        public void AddRide(ride ride)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            db.rides.Add(ride);
            db.SaveChanges();
        }

        public bool Remove(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            ride ride = (from rides in db.rides where rides.rideId == id select rides).FirstOrDefault();
            if (ride == null) return false;
            db.rides.Remove(ride);
            db.SaveChanges();
            return true;
        }

        public ride getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            ride ride = (from rides in db.rides where rides.rideId == id select rides).FirstOrDefault();
            return ride;
        }
    }
}
