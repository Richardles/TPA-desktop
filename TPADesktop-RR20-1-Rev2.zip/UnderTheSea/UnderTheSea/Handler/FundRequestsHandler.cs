﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class FundRequestsHandler
    {
        private FundRequestsRepo fundRepo;
        private static FundRequestsHandler handler;

        private FundRequestsHandler()
        {
            this.fundRepo = new FundRequestsRepo();
        }

        public static FundRequestsHandler GetInstance()
        {
            return (handler == null) ? handler = new FundRequestsHandler() : handler;
        }

        public List<fundRequest> GetAll()
        {
            return fundRepo.GetAll();
        }
        public bool InsertReq(string id, string dept, string req, string status)
        {
            fundRequest fund = FundRequestsFactory.CreateReq(int.Parse(id), dept, req, status);
            fundRepo.AddReq(fund);
            return true;
        }

        public bool Update(string id, string status)
        {
            fundRequest temp = fundRepo.getOne(int.Parse(id));
            fundRepo.Remove(int.Parse(id));
            fundRequest fund = FundRequestsFactory.CreateReq(int.Parse(id), temp.department, temp.request, status);
            fundRepo.AddReq(fund);
            return true;
        }
        public fundRequest getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            fundRequest fund = (from funds in db.fundRequests where funds.id == id select funds).FirstOrDefault();
            return fund;
        }
    }
}
