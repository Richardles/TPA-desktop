﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class AttractionHandler
    {
        private AttractionRepo attractionRepo;
        private static AttractionHandler handler;

        private AttractionHandler()
        {
            this.attractionRepo = new AttractionRepo();
        }

        public static AttractionHandler GetInstance()
        {
            return (handler == null) ? handler = new AttractionHandler() : handler;
        }

        public List<attraction> GetAll()
        {
            return attractionRepo.GetAll();
        }
        public bool InsertAttr(string id, string name, string desc, string status, string guards)
        {
            attraction attr = AttractionFactory.CreateAttr(int.Parse(id), name, desc, status, guards);
            attractionRepo.AddAttr(attr);
            return true;
        }

        public bool Remove(int id)
        {
            attraction temp = attractionRepo.getOne(id);
            attractionRepo.Remove(id);
            attraction attr = AttractionFactory.CreateAttr(temp.attractionId, temp.name, temp.description, "Removed", temp.guards);
            attractionRepo.AddAttr(attr);
            return true;
        }

        public bool Update(string id, string name, string desc, string status)
        {
            attraction temp = attractionRepo.getOne(int.Parse(id));
            attractionRepo.Remove(int.Parse(id));
            attraction attr = AttractionFactory.CreateAttr(int.Parse(id), name, desc, status, temp.guards);
            attractionRepo.AddAttr(attr);
            return true;
        }

        public bool Update(int id, string guards)
        {
            attraction temp = attractionRepo.getOne(id);
            attractionRepo.Remove(id);
            attraction attr = AttractionFactory.CreateAttr(id, temp.name, temp.description, temp.status, guards);
            attractionRepo.AddAttr(attr);
            return true;
        }

        public bool Update(string ids, string status)
        {
            int id = int.Parse(ids);
            attraction temp = attractionRepo.getOne(id);
            attractionRepo.Remove(id);
            attraction attr = AttractionFactory.CreateAttr(id, temp.name, temp.description, status, temp.guards);
            attractionRepo.AddAttr(attr);
            return true;
        }
    }
}
