﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class PurchaseRequestHandler
    {
        private PurchaseRequestRepo purRepo;
        private static PurchaseRequestHandler handler;

        private PurchaseRequestHandler()
        {
            this.purRepo = new PurchaseRequestRepo();
        }

        public static PurchaseRequestHandler GetInstance()
        {
            return (handler == null) ? handler = new PurchaseRequestHandler() : handler;
        }

        public List<purchase> GetAll()
        {
            return purRepo.GetAll();
        }
        public bool InsertReq(string id, string dept, string req, string status)
        {
            purchase pur = PurchasesRequestFactory.CreateReq(int.Parse(id), dept, req, status);
            purRepo.AddReq(pur);
            return true;
        }

        public bool Update(string id, string status)
        {
            purchase temp = purRepo.getOne(int.Parse(id));
            purRepo.Remove(int.Parse(id));
            purchase pur = PurchasesRequestFactory.CreateReq(int.Parse(id), temp.department, temp.request, status);
            purRepo.AddReq(pur);
            return true;
        }
        public purchase getOne(int id)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            purchase pur = (from purs in db.purchases where purs.id == id select purs).FirstOrDefault();
            return pur;
        }
    }
}
