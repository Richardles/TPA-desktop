﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class RideHandler
    {
        private RideRepo rideRepo;
        private static RideHandler handler;

        private RideHandler()
        {
            this.rideRepo = new RideRepo();
        }

        public static RideHandler GetInstance()
        {
            return (handler == null) ? handler = new RideHandler() : handler;
        }

        public List<ride> GetAll()
        {
            return rideRepo.GetAll();
        }

        public bool InsertRide(string id, string name, string desc, string status, string guards)
        {
            ride ride = RideFactory.CreateRide(int.Parse(id), name, desc, status, guards);
            rideRepo.AddRide(ride);
            return true;
        }

        public bool Remove(int id)
        {
            ride temp = rideRepo.getOne(id);
            rideRepo.Remove(id);
            ride ride = RideFactory.CreateRide(temp.rideId,temp.name, temp.description, "Removed", temp.guards);
            rideRepo.AddRide(ride);
            return true;
        }

        public bool Update(string id, string name, string desc, string status)
        {
            ride temp = rideRepo.getOne(int.Parse(id));
            rideRepo.Remove(int.Parse(id));
            ride ride = RideFactory.CreateRide(int.Parse(id), name, desc, status, temp.guards);
            rideRepo.AddRide(ride);
            return true;
        }

        public bool Update(string id, string status)
        {
            ride temp = rideRepo.getOne(int.Parse(id));
            rideRepo.Remove(int.Parse(id));
            ride ride = RideFactory.CreateRide(int.Parse(id), temp.name, temp.description, status, temp.guards);
            rideRepo.AddRide(ride);
            return true;
        }

        public bool Update(int id, string guards)
        {
            ride temp = rideRepo.getOne(id);
            rideRepo.Remove(id);
            ride ride = RideFactory.CreateRide(id, temp.name, temp.description, temp.status, guards);
            rideRepo.AddRide(ride);
            return true;
        }
    }
}
