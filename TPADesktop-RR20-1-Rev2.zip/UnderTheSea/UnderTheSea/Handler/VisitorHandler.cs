﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class VisitorHandler
    {
        private VisitorRepo visitorRepo;
        private static VisitorHandler handler;

        private VisitorHandler()
        {
            this.visitorRepo = new VisitorRepo();
        }

        public static VisitorHandler GetInstance()
        {
            return (handler == null) ? handler = new VisitorHandler() : handler;
        }

        public bool InsertVisitor(string name, string payType, string bankAcc)
        {
            visitor visitor = VisitorFactory.CreateVisitor(name, payType, bankAcc);
            visitorRepo.AddVisitor(visitor);
            return true;
        }
        public visitor GetOne(int id)
        {
            visitor temp = visitorRepo.getOne(id);
            return temp;
        }
    }
}
