﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class EmployeeHandler
    {
        private EmployeeRepo empRepo;
        private static EmployeeHandler handler;

        private EmployeeHandler()
        {
            this.empRepo = new EmployeeRepo();
        }

        public static EmployeeHandler GetInstance()
        {
            return (handler == null) ? handler = new EmployeeHandler() : handler;
        }

        public List<employee> GetAll()
        {
            return empRepo.GetAll();
        }

        public bool InsertEmp(string id, string pass, string name, string salary, string position, string status, string bankAcc, string workPerf)
        {
            employee emp = EmployeeFactory.CreateEmp(int.Parse(id), pass, name, salary, position, status, bankAcc, workPerf);
            empRepo.AddEmp(emp);
            return true;
        }

        public bool Fire(string id)
        {
            employee temp = empRepo.getOne(int.Parse(id));
            empRepo.Remove(int.Parse(id));
            employee emp = EmployeeFactory.CreateEmp(temp.id, temp.password, temp.name, temp.salary, temp.position, "Fired", temp.bank_account, temp.work_performance);
            empRepo.AddEmp(emp);
            return true;
        }

        public bool Update(string id, string pass, string name, string salary, string position, string status, string bankAcc, string workPerf)
        {
            employee temp = empRepo.getOne(int.Parse(id));
            empRepo.Remove(int.Parse(id));
            employee emp = EmployeeFactory.CreateEmp(int.Parse(id), pass, name, salary, position, status, bankAcc, workPerf);
            empRepo.AddEmp(emp);
            return true;
        }

        public bool Update(int id, string status)
        {
            employee temp = empRepo.getOne(id);
            empRepo.Remove(id);
            employee emp = EmployeeFactory.CreateEmp(id, temp.password, temp.name, temp.salary, temp.position, status, temp.bank_account, temp.work_performance);
            empRepo.AddEmp(emp);
            return true;
        }

        public employee getOne(string username)
        {
            return empRepo.getOne(username);
        }

    }
}
