﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.AdFactory;
using UnderTheSea.Model;
using UnderTheSea.Repo;

namespace UnderTheSea.Handler
{
    class ResignReqHandler
    {
        private ResignReqRepo reqRepo;
        private static ResignReqHandler handler;

        private ResignReqHandler()
        {
            this.reqRepo = new ResignReqRepo();
        }

        public static ResignReqHandler GetInstance()
        {
            return (handler == null) ? handler = new ResignReqHandler() : handler;
        }

        public List<resignReq> GetAll()
        {
            return reqRepo.GetAll();
        }

        public bool InsertReq(string id, string name, string position, string desc, string status)
        {
            resignReq req = ResignLetterFactory.CreateReq(int.Parse(id), name, position, desc, status);
            reqRepo.AddReq(req);
            return true;
        }

        public bool Update(int id, string status)
        {
            resignReq temp = reqRepo.getOne(id);
            reqRepo.Remove(id);
            resignReq req = ResignLetterFactory.CreateReq(id, temp.name, temp.position, temp.description, status);
            reqRepo.AddReq(req);
            return true;
        }

        public resignReq getOne(int id)
        {
            return reqRepo.getOne(id);
        }
    }
}
