﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;
using UnderTheSea.View;

namespace UnderTheSea
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, RoutedEventArgs e)
        {
            employee emp = EmployeeHandler.GetInstance().getOne(usernameField.Text);
            if (emp != null)
            {
                if (pass_field.Password == emp.password)
                {
                    checkPos(emp.position);
                }
                else
                {
                    MessageBox.Show("Wrong Password");
                }
            }
            else
            {
                MessageBox.Show("User not found");
            }
        }

        public void checkPos(string pos)
        {
            if (pos.Equals("Sales and Marketing"))
            {
                SalesAndMarketingUI sm = new SalesAndMarketingUI();
                sm.Show();
                this.Close();
            }
            else if (pos.Equals("Accounting and Finance"))
            {
                AccountingAndFinanceUI ac = new AccountingAndFinanceUI();
                ac.Show();
                this.Close();
            }
            else if (pos.Equals("Ride and Attraction Creative"))
            {
                RideandAttractionCreativeDepartment c = new RideandAttractionCreativeDepartment();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("Construction"))
            {
                ConstructionUI c = new ConstructionUI();
                c.Show();
                this.Close();
            }
            else if (pos.Equals("HRD"))
            {
                HRDUI h = new HRDUI();
                h.Show();
                this.Close();
            }
            else if (pos.Equals("Manager"))
            {
                Manager m = new Manager();
                m.Show();
                this.Close();
            }
            else if (pos.Equals("Attraction"))
            {
                AttractionDepartmentUI a = new AttractionDepartmentUI();
                a.Show();
                this.Close();
            }
            else if (pos.Equals("Maintenance"))
            {
                MaintenanceUI a = new MaintenanceUI();
                a.Show();
                this.Close();
            }
            else if (pos.Equals("Front Office"))
            {
                FrontOfficeUI a = new FrontOfficeUI();
                a.Show();
                this.Close();
            }
            else if (pos.Equals("House Keeping"))
            {
                HouseKeeping a = new HouseKeeping();
                a.Show();
                this.Close();
            }
            else if (pos.Equals("Purchasing"))
            {
                PurchasingUI a = new PurchasingUI();
                a.Show();
                this.Close();
            }
        }
    }
}
