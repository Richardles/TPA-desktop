﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea
{
    /// <summary>
    /// Interaction logic for SalesAndMarketingUI.xaml
    /// </summary>
    public partial class SalesAndMarketingUI : Window
    {
        public SalesAndMarketingUI()
        {
            InitializeComponent();
            ViewAdvertisement();
        }

        private void ViewAdvertisement()
        {
            var advertisements = AdvertisementHandler.GetInstance().GetAll();
            adView.ItemsSource = advertisements;
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(idField.Text);
            var idea = ideaField.Text;
            var status = statusField.Text;
            AdvertisementHandler.GetInstance().InsertAd(id, idea, status);
            Refresh();
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(idField.Text);
            AdvertisementHandler.GetInstance().Remove(id);
            Refresh();
        }

        private void Refresh()
        {
            ViewAdvertisement();
            idField.Text = "";
            ideaField.Text = "";
            statusField.Text = "";
            purchase_field.Text = "";
            fund_field.Text = "";
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(idField.Text);
            var idea = ideaField.Text;
            var status = statusField.Text;
            var purchase = purchase_field.Text;
            var fun = fund_field.Text;
            AdvertisementHandler.GetInstance().Delete(id);
            AdvertisementHandler.GetInstance().InsertAd(id, idea, status, purchase, fun);
            Refresh();
        }

        private void Purchase_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(idField.Text);
            var purchase = purchase_field.Text;
            if (!purchase.Trim().Equals(""))
            {
                AdvertisementHandler.GetInstance().RequestPurchase(id, purchase);
                Refresh();
            }
        }

        private void Fund_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(idField.Text);
            var fund = fund_field.Text;
            if (!fund.Trim().Equals(""))
            {
                AdvertisementHandler.GetInstance().RequestFund(id, fund);
                Refresh();
            }
        }

        private void AdView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = sender as DataGrid;
            var ad = (advertisementIdea)a.SelectedItem;
            if (ad != null)
            {
                idField.Text = ad.id.ToString();
                ideaField.Text = ad.idea;
                statusField.Text = ad.status;
                purchase_field.Text = ad.Purchase_Request;
                fund_field.Text = ad.Fund_Request;
            }
        }
    }
}
