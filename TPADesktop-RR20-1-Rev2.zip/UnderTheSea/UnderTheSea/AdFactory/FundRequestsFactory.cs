﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class FundRequestsFactory
    {
        public static fundRequest CreateReq(int id, string dept, string req, string status)
        {
            fundRequest fund = new fundRequest();
            fund.id = id;
            fund.department = dept;
            fund.request = req;
            fund.status = status;
            return fund;
        }
    }
}
