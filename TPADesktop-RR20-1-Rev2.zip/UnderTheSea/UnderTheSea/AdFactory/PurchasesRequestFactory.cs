﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class PurchasesRequestFactory
    {
        public static purchase CreateReq(int id, string dept, string req, string status)
        {
            purchase pur = new purchase();
            pur.id = id;
            pur.department = dept;
            pur.request = req;
            pur.status = status;
            return pur;
        }
    }
}
