﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class AttractionFactory
    {
        public static attraction CreateAttr(int id, string name, string desc, string status, string guards)
        {
            attraction attr = new attraction();
            attr.attractionId = id;
            attr.name = name;
            attr.description = desc;
            attr.status = status;
            attr.guards = guards;
            return attr;
        }
    }
}
