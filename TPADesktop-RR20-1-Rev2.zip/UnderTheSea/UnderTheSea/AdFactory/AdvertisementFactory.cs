﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class AdvertisementFactory
    {
        public static advertisementIdea CreateAd(int id, string idea, string status)
        {
            advertisementIdea ad = new advertisementIdea();
            ad.id = id;
            ad.idea = idea;
            ad.status = status;
            return ad;
        }
        public static advertisementIdea CreateAd(int id, string idea, string status, string purchase, string fund)
        {
            advertisementIdea ad = new advertisementIdea();
            ad.id = id;
            ad.idea = idea;
            ad.status = status;
            ad.Purchase_Request = purchase;
            ad.Fund_Request = fund;
            return ad;
        }
        public static advertisementIdea CreateAd(int id, string idea, string status, string purReq, string fundReq, string reqStatus)
        {
            advertisementIdea ad = new advertisementIdea();
            ad.id = id;
            ad.idea = idea;
            ad.status = status;
            ad.Purchase_Request = purReq;
            ad.Fund_Request = fundReq;
            ad.Request_Status = reqStatus;
            return ad;
        }
    }
}
