﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class VisitorFactory
    {
        public static visitor CreateVisitor(string name, string payType, string bankAcc)
        {
            visitor v = new visitor();
            v.name = name;
            v.payment_type = payType;
            v.bank_account = bankAcc;
            return v;
        }
    }
}
