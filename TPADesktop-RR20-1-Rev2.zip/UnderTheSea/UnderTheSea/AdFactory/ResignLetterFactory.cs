﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class ResignLetterFactory
    {
        public static resignReq CreateReq(int id, string name, string position, string desc, string status)
        {
            UnderTheSeaEntities1 db = new UnderTheSeaEntities1();
            resignReq req = new resignReq();
            req.id = id;
            req.name = name;
            req.position = position;
            req.description = desc;
            req.status = status;
            return req;
        }
    }
}
