﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class EmployeeFactory
    {
        public static employee CreateEmp(int id, string pass, string name, string salary, string position, string status, string bankAcc, string workPerf)
        {
            employee emp = new employee();
            emp.id = id;
            emp.name = name;
            emp.password = pass;
            emp.salary = salary;
            emp.position = position;
            emp.status = status;
            emp.bank_account = bankAcc;
            emp.work_performance = workPerf;
            return emp;
        }
    }
}
