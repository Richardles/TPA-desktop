﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea.Model;

namespace UnderTheSea.AdFactory
{
    class RideFactory
    {
        public static ride CreateRide(string name, string desc, string status, string guards)
        {
            ride ride = new ride();
            ride.name = name;
            ride.description = desc;
            ride.status = status;
            ride.guards = guards;
            return ride;
        }

        public static ride CreateRide(int id, string name, string desc, string status, string guards)
        {
            ride ride = new ride();
            ride.rideId = id;
            ride.name = name;
            ride.description = desc;
            ride.status = status;
            ride.guards = guards;
            return ride;
        }
    }
}
