﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnderTheSea.Handler;
using UnderTheSea.Model;

namespace UnderTheSea.View
{
    /// <summary>
    /// Interaction logic for AccountingAndFinanceUI.xaml
    /// </summary>
    public partial class AccountingAndFinanceUI : Window
    {
        private string reqStatus = "";
        string currView;
        public AccountingAndFinanceUI()
        {
            InitializeComponent();
            ViewAdvertisement();
        }

        private void ViewAdvertisement()
        {
            var advertisements = AdvertisementHandler.GetInstance().GetAll();
            adView.ItemsSource = advertisements;
            currView = "ad";
        }
        private void ViewAllReq()
        {
            var req = FundRequestsHandler.GetInstance().GetAll();
            adView.ItemsSource = req;
            currView = "req";
        }

        private void logout_Btn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void AdView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (currView.Equals("ad"))
            {
                var a = sender as DataGrid;
                var ad = (advertisementIdea)a.SelectedItem;
                if (ad != null)
                {
                    var id = ad.id.ToString();
                    id_lbl.Content = id;
                    if (ad.Request_Status != null && !ad.Request_Status.ToString().Equals(""))
                        reqStatus = ad.Request_Status.ToString();
                }
            }else if (currView.Equals("req"))
            {
                var a = sender as DataGrid;
                var ad = (fundRequest)a.SelectedItem;
                if (ad != null)
                {
                    var id = ad.id.ToString();
                    id_lbl.Content = id;
                }
            }
        }

        private void approve_Click(object sender, RoutedEventArgs e)
        {
            if (currView.Equals("ad"))
            {
                if (!reqStatus.Trim().Equals(""))
                {
                    int id = int.Parse(id_lbl.Content.ToString());
                    AdvertisementHandler.GetInstance().Update(id, "Approved");
                    ViewAdvertisement();
                }
            }
            else if (currView.Equals("req"))
            {
                int id = int.Parse(id_lbl.Content.ToString());
                FundRequestsHandler.GetInstance().Update(id.ToString(), "Approved");
                ViewAllReq();
            }
        }

        private void reject_Click(object sender, RoutedEventArgs e)
        {
            if (currView.Equals("ad"))
            {
                if (!reqStatus.Trim().Equals(""))
                {
                    int id = int.Parse(id_lbl.Content.ToString());
                    AdvertisementHandler.GetInstance().Update(id, "Rejected");
                    ViewAdvertisement();
                }
            }
            else if (currView.Equals("req"))
            {
                int id = int.Parse(id_lbl.Content.ToString());
                FundRequestsHandler.GetInstance().Update(id.ToString(), "Rejected");
                ViewAllReq();
            }
        }

        private void view_all_Click(object sender, RoutedEventArgs e)
        {
            ViewAllReq();
        }

        private void view_ad_Click(object sender, RoutedEventArgs e)
        {
            ViewAdvertisement();
        }
    }
}
